//
// This file exists so that CocoaPods will generate a modulemap for CardIO
//
// See https://github.com/card-io/card.io-iOS-SDK/issues/115
// and https://github.com/card-io/card.io-iOS-SDK/pull/126
// for more details
//
